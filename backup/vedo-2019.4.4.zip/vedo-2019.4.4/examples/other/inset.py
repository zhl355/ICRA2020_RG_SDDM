"""
Renderer meshes into insets.
(can be dragged)
"""
from vtkplotter import *

vp = Plotter(axes=1, bg="white")

e = load(datadir+"embryo.tif", threshold=True) # automatic isosurfacing
e.normalize().c("gold")
msg = Text(__doc__)

vp.show(e, msg, viewup='z', interactive=0)

e1 = e.clone().cutWithPlane(normal=[1,0,0]).c("red")
e2 = e.clone().cutWithPlane(normal=[0,1,0]).c("pink")
e3 = e.clone().cutWithPlane(normal=[0,0,1]).c("blue")

vp.showInset(e1, pos=(0.9,0.2))
vp.showInset(e2, pos=(0.9,0.5))
vp.showInset(e2, e3, pos=(0.9,0.8))

vp.show(interactive=1)
